# Rule-Based Expert System
# Forward Chaining Implementation
# Knowledge Base (IF–THEN Rules)

rules = [
    ({"fever", "cough"}, "flu"),
    ({"fever", "rash"}, "measles"),
    ({"flu", "headache"}, "viral_infection"),
    ({"measles"}, "consult_doctor"),
    ({"viral_infection"}, "take_rest")
]


# Forward Chaining Function

def forward_chaining(facts, rules):
    reasoning_steps = []
    new_fact_added = True

    while new_fact_added:
        new_fact_added = False

        for condition, conclusion in rules:
            if condition.issubset(facts) and conclusion not in facts:
                facts.add(conclusion)
                new_fact_added = True
                reasoning_steps.append(
                    f"Applied Rule: IF {', '.join(condition)} THEN {conclusion}"
                )

    return facts, reasoning_steps

# User Input (Facts / Symptoms)

print("=== Rule-Based Expert System ===")
print("Enter symptoms separated by commas")
print("Example: fever,cough,headache")

user_input = input("Symptoms: ")

facts = set(symptom.strip().lower() for symptom in user_input.split(","))

# Run Expert System

final_facts, log = forward_chaining(facts, rules)


# Output Reasoning Steps

print("\n--- Reasoning Steps ---")
if log:
    for step in log:
        print(step)
else:
    print("No rules applied")

# Final Conclusion
print("\n--- Final Facts / Conclusions ---")
for fact in final_facts:
    print(fact)
